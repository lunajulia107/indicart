<svg width='48' height='49' viewBox='0 0 48 49' fill='none' xmlns='http://www.w3.org/2000/svg'>
    <g clip-path='url(#clip0_234_1108)'>
        <path d='M25.2787 43.79C24.6168 44.0582 23.8835 44.0582 23.2216 43.79C18.0566 41.708 13.6147 38.0297 10.4826 33.2412C7.35041 28.4527 5.67538 22.7791 5.67873 16.97V9.14002C5.67716 8.81152 5.77633 8.49122 5.96157 8.22648C6.14681 7.96174 6.40828 7.76664 6.7073 7.67002C18.1555 4.10063 30.3448 4.10063 41.793 7.67002C42.092 7.76664 42.3535 7.96174 42.5388 8.22648C42.724 8.49122 42.8232 8.81152 42.8216 9.14002V16.97C42.8249 22.7791 41.1499 28.4527 38.0178 33.2412C34.8856 38.0297 30.4437 41.708 25.2787 43.79Z' stroke='url(#paint0_linear_234_1108)' stroke-width='3' stroke-linecap='round' stroke-linejoin='round' />
        <path d='M22.2071 25.4423C21.8166 25.8328 21.1834 25.8328 20.7929 25.4423L18.8077 23.4571C18.4172 23.0666 17.784 23.0666 17.3935 23.4571L16.9571 23.8935C16.5666 24.284 16.5666 24.9172 16.9571 25.3077L20.7929 29.1435C21.1834 29.534 21.8166 29.534 22.2071 29.1435L31.2929 20.0577C31.6834 19.6672 31.6834 19.034 31.2929 18.6435L30.8565 18.2071C30.466 17.8166 29.8328 17.8166 29.4423 18.2071L22.2071 25.4423Z' fill='url(#paint1_linear_234_1108)' />
    </g>
    <defs>
        <linearGradient id='paint0_linear_234_1108' x1='3.45014' y1='15.9125' x2='25.7016' y2='48.4586' gradientUnits='userSpaceOnUse'>
            <stop stop-color='#93278F' />
            <stop offset='0.277506' stop-color='#4F2894' />
            <stop offset='0.521208' stop-color='#005BAA' />
            <stop offset='0.927335' stop-color='#94E6FF' />
        </linearGradient>
        <linearGradient id='paint1_linear_234_1108' x1='15.305' y1='20.9582' x2='21.431' y2='32.9553' gradientUnits='userSpaceOnUse'>
            <stop stop-color='#93278F' />
            <stop offset='0.277506' stop-color='#4F2894' />
            <stop offset='0.521208' stop-color='#005BAA' />
            <stop offset='0.927335' stop-color='#94E6FF' />
        </linearGradient>
        <clipPath id='clip0_234_1108'>
            <rect width='40' height='42' fill='white' transform='translate(4.25 3.5)' />
        </clipPath>
    </defs>
</svg>
