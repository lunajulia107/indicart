import React from "react";

const MenuMobile = () => {
  return (
    <header className="border-bottom navbar navbar-expand-lg"> 
    </header>
  );
};

export default MenuMobile;
