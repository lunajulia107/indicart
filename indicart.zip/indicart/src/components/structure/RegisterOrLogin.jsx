import React from "react";

const RegisterOrLogin = () => {
    return (
        <>
            <div className="align-items-center bg-white d-flex flex-column gap-3 justify-content-center p-3">  
                <h5 className="ff-roundend">Seja bem-vindo!</h5>

                <div className="d-flex flex-row">
                    <button className="btn-gradient text-white" type="button">Login</button>
                    <button className="btn-gradient text-white" type="button">Cadastre-se</button>
                </div>

                <div>
                    <div className="d-flex flex-column gap-2 login">
                        <div>
                            <input className="border-0 border-bottom form-control" type="text" placeholder="CPF ou E-mail" />
                        </div>
                        <div>
                            <input className="border-0 border-bottom form-control" type="password" placeholder="Senha" />
                        </div>
                        <p><a className="text-darker-gray50" href="#">Esqueceu a senha?</a></p>
                        <button className="border-0 btn-gradient text-white" type="button">Logar</button>

                        <div className="d-flex flex-column gap-2">
                            <p className="text-center">Ou continue com</p>

                            <div className="d-flex flex-row gap-3">
                                <a href="http://"><img src="../images/stucture/google.svg" alt="" srcset="" /></a>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
            {/* <div class="group-230">
                <div class="box">
                    <div class="rectangle-199"></div>
                    <div class="frame-244">
                        <div class="frame-115">
                            <div class="cadastre-se">Cadastre-se</div>
                            <div class="s-o-apenas-dois-passos">São apenas dois passos</div>
                        </div>
                        <div class="group-222">
                            <div class="rectangle-78"></div>
                            <div class="rectangle-79"></div>
                            <div class="login-2-pop-up">
                                <div class="login">Login</div>
                            </div>
                            <div class="cadastre-se2">Cadastre-se</div>
                        </div>
                        <div class="inputs">
                            <div class="underline-input">
                                <img class="ret-ngulo-1607" src="ret-ngulo-16070.svg" />
                                <img class="linha-184" src="linha-1840.svg" />
                                <div class="cpf-ou-email">E-mail</div>
                            </div>
                            <div class="underline-input2">
                                <img class="linha-1842" src="linha-1841.svg" />
                                <div class="senha">Senha</div>
                            </div>
                        </div>
                        <div class="continuar-pop-up">
                            <div class="button">
                                <div class="get-started">Continue</div>
                            </div>
                        </div>
                        <div class="frame-2442">
                            <div class="esqueceu-a-senha">Ou continue cadastra-se com</div>
                            <div class="redes">
                                <img class="google" src="google0.png" />
                                <img class="clip-path-group" src="clip-path-group0.svg" />
                                <img class="apple" src="apple0.png" />
                            </div>
                        </div>
                    </div>
                </div>
            </div> */} 


            {/* <div class="frame-244">
                <div class="frame-115">
                    <div class="seja-bem-vindo">Seja bem-vindo!</div>
                </div>
                <div class="group-222">
                    <div class="rectangle-78"></div>
                    <div class="rectangle-79"></div>
                    <div class="login">Login</div>
                    <div class="cadastro-2-pop-up">
                        <div class="cadastre-se">Cadastre-se</div>
                    </div>
                </div>
                <div class="inputs">
                    <div class="underline-input">
                        <img class="ret-ngulo-1607" src="ret-ngulo-16070.svg" />
                        <img class="linha-184" src="linha-1840.svg" />
                        <div class="cpf-ou-email">CPF ou Email</div>
                    </div>
                    <div class="underline-input">
                        <img class="ret-ngulo-16072" src="ret-ngulo-16071.svg" />
                        <img class="linha-1842" src="linha-1841.svg" />
                        <div class="senha">Senha</div>
                    </div>
                </div>
                <div class="group-244">
                    <div class="login-pop-up">
                        <div class="button">
                            <div class="get-started">Login</div>
                        </div>
                    </div>
                    <div class="esqueceu-a-senha">Esqueceu a senha?</div>
                </div>
                <div class="frame-2442">
                    <div class="esqueceu-a-senha2">Ou continue com</div>
                    <div class="redes">
                        <img class="google" src="google0.png" />
                        <img class="clip-path-group" src="clip-path-group0.svg" />
                        <img class="apple" src="apple0.png" />
                    </div>
                </div>
            </div>  */}
        </> 
    );
};

export default RegisterOrLogin;

